const { getStore } = require('@netlify/blobs');

const INITIAL_SUPPLIERS = [
  { id:"g1", name:"AGC", specialty:"Float glass, laminated glass, coated glass, solar control glass, tempered glass — major commercial projects", contact:"agc.com", notes:"🔴 Glass – Major Projects" },
  { id:"g2", name:"Saint-Gobain Glass", specialty:"Float glass, tempered glass, coated glass, laminated glass, acoustic glass — major commercial", contact:"saint-gobain.com", notes:"🔴 Glass – Major Projects" },
  { id:"g3", name:"Pilkington / NSG", specialty:"Float glass, fire-resistant glass, self-cleaning glass, solar control glass — major projects", contact:"pilkington.com", notes:"🔴 Glass – Major Projects" },
  { id:"g4", name:"Press Glass", specialty:"Tempered glass, laminated glass, IGUs, toughened glass — major commercial projects", contact:"pressglass.co.uk", notes:"🔴 Glass – Major Projects" },
  { id:"g5", name:"UKO Glass", specialty:"Standard glazing, toughened glass, IGUs, day-to-day glass supply", contact:"ukoglass.co.uk", notes:"🟠 Glass – Standard" },
  { id:"g6", name:"Performance Glass", specialty:"Standard glass supply, toughened glass, IGUs, day-to-day", contact:"performanceglass.co.uk", notes:"🟠 Glass – Standard" },
  { id:"g7", name:"LAG Glass", specialty:"Standard glass supply, glazing products — London-based", contact:"lag.glass", notes:"🟠 Glass – Standard" },
  { id:"g8", name:"Triple Warm", specialty:"Standard glazing, triple glazing, IGUs, day-to-day glass supply", contact:"", notes:"🟠 Glass – Standard ⭐ Main Supplier" },
  { id:"f1", name:"FIRNTEC", specialty:"Fire-rated glazing, fire doors, fire-resistant glass panels, intumescent seals", contact:"", notes:"🔵 Fire-Rated Systems" },
  { id:"f2", name:"Pyroguard", specialty:"Fire-rated glass, fire protection glazing, fire-resistant facade systems", contact:"", notes:"🔵 Fire-Rated Systems" },
  { id:"f3", name:"OWS Fire Rated", specialty:"Fire-rated glazing systems, fire-rated curtain wall, fire-resistant windows and doors", contact:"owsfirerated.co.uk", notes:"🔵 Fire-Rated Systems" },
  { id:"f4", name:"Alufire", specialty:"Fire-rated aluminium systems, fire-rated doors, fire-rated curtain wall, aluminium fire screens", contact:"alufire.com", notes:"🔵 Fire-Rated Systems" },
  { id:"bl1", name:"Morley Glass", specialty:"Integral blinds in glass, sealed unit integral blinds, Uni-Blinds systems", contact:"morleyglass.co.uk", notes:"🟡 Blinds" },
  { id:"c1", name:"Warringtonfire", specialty:"Fire testing, fire certification, fire engineering consultancy", contact:"warringtonfire.com", notes:"⚫ Testing / Certification" },
  { id:"c2", name:"FFCert", specialty:"Fire-rated product certification, facade fire certification", contact:"ffcert.com", notes:"⚫ Testing / Certification" },
  { id:"c3", name:"Element", specialty:"Testing, inspection, certification — building materials and facades", contact:"element.com", notes:"⚫ Testing / Certification" },
  { id:"c4", name:"Assured Fire Safety", specialty:"Fire safety consultancy, FDS certification, fire door inspection", contact:"assuredfds.com", notes:"⚫ Testing / Certification" },
  { id:"c5", name:"Checkmate Fire", specialty:"Fire safety services, fire door inspection, passive fire protection", contact:"checkmatefire.com", notes:"⚫ Testing / Certification" },
  { id:"c6", name:"Elev8 Fire Engineering", specialty:"Fire engineering consultancy, fire strategy, facade fire assessment", contact:"elev8fireengineering.com", notes:"⚫ Testing / Certification" },
  { id:"c7", name:"Future Fire Solutions", specialty:"Fire safety consultancy, passive fire protection, fire stopping", contact:"futurefiresolutions.com", notes:"⚫ Testing / Certification" },
  { id:"c8", name:"Fire Inspections", specialty:"Fire door and passive fire protection inspections, compliance checks", contact:"fireinspections.co.uk", notes:"⚫ Testing / Certification" },
  { id:"c9", name:"Fire Consulting", specialty:"Fire engineering consultancy, fire risk assessment, fire strategy", contact:"fireconsulting.co.uk", notes:"⚫ Testing / Certification" },
  { id:"a1", name:"Reynaers", specialty:"Aluminium windows, doors, curtain wall, sliding systems, bifolding doors, facade systems", contact:"reynaers.com", notes:"🟢 Aluminium Systems ⭐ Main Supplier" },
  { id:"a2", name:"Schüco", specialty:"Aluminium windows, doors, curtain wall, sliding systems, facade systems", contact:"schueco.com", notes:"🟢 Aluminium Systems" },
  { id:"a3", name:"Aluprof", specialty:"Aluminium windows, doors, curtain wall, tilt & turn systems, sliding doors", contact:"aluprof.co.uk", notes:"🟢 Aluminium Systems" },
  { id:"a4", name:"AluK", specialty:"Aluminium windows, doors, curtain wall, commercial facades", contact:"aluk.com", notes:"🟢 Aluminium Systems" },
  { id:"a5", name:"Cortizo", specialty:"Aluminium systems, windows, doors, curtain wall, sliding systems", contact:"cortizo.com", notes:"🟢 Aluminium Systems" },
  { id:"a6", name:"Hydro", specialty:"Aluminium extrusions, aluminium profiles, building systems, raw aluminium supply", contact:"hydro.com", notes:"🟢 Aluminium Systems" },
  { id:"a7", name:"Aluron", specialty:"Aluminium windows, doors, curtain wall systems, sliding systems", contact:"aluron.eu", notes:"🟢 Aluminium Systems" },
  { id:"a8", name:"Kestrel Aluminium", specialty:"Aluminium windows, doors, commercial facades, curtain wall", contact:"kestrelaluminium.co.uk", notes:"🟢 Aluminium Systems" },
  { id:"a9", name:"Murus Facades", specialty:"Aluminium curtain wall, windows, doors, fenestration, facade systems", contact:"murusfacades.co.uk", notes:"🟢 Aluminium Systems" },
  { id:"a10", name:"Arkoni", specialty:"Glass, glazing, facade glazing, bespoke glazing", contact:"", notes:"🟢 Aluminium Systems" },
  { id:"a11", name:"Arcora", specialty:"Aluminium facade systems, major commercial curtain wall, complex facades", contact:"arcora.com", notes:"🟢 Aluminium Systems" },
  { id:"a12", name:"Gennaro", specialty:"Windows, aluminium doors, glazed framing, aluminium curtain wall", contact:"", notes:"🟢 Aluminium Systems" },
  { id:"u1", name:"Euroglaze", specialty:"uPVC windows, uPVC doors, casement windows, tilt & turn, residential glazing", contact:"euroglaze.co.uk", notes:"🟣 uPVC ⭐ Main Supplier" },
  { id:"u2", name:"Polyframe", specialty:"uPVC windows, uPVC doors, residential glazing systems, profile systems", contact:"", notes:"🟣 uPVC ⭐ Main Supplier" },
  { id:"u3", name:"GAP", specialty:"uPVC profiles, windows, doors, building products", contact:"gap.uk.com", notes:"🟣 uPVC" },
  { id:"u4", name:"Kalsi Plastics", specialty:"uPVC products, plastic extrusions, building plastics", contact:"kalsiplastics.co.uk", notes:"🟣 uPVC" },
  { id:"u5", name:"Drutex", specialty:"uPVC and aluminium windows, doors — international supply", contact:"drutex.com.pl", notes:"🟣 uPVC" },
  { id:"u6", name:"Eko-Okna", specialty:"uPVC windows, doors — international supply", contact:"ekookna.pl", notes:"🟣 uPVC" },
  { id:"u7", name:"DAKO", specialty:"uPVC and aluminium windows, doors — international supply", contact:"dako.eu", notes:"🟣 uPVC" },
  { id:"dp1", name:"Hallmark Doors & Panels", specialty:"uPVC door panels, composite door panels, residential door skins, door cassettes", contact:"hallmarkpanels.com", notes:"🟤 uPVC Door Panels" },
  { id:"ep1", name:"Plastim", specialty:"Engineering plastics, plastic sheets, polycarbonate, acrylic, nylon, HDPE sheets", contact:"plastim.co.uk", notes:"⚪ Engineering Plastics" },
  { id:"ep2", name:"Plastic Sheets Shop", specialty:"Plastic sheets, polycarbonate, acrylic, PVC sheets, engineering plastics", contact:"plasticsheetsshop.co.uk", notes:"⚪ Engineering Plastics" },
  { id:"ep3", name:"Ensinger Plastics", specialty:"High-performance engineering plastics, thermal break profiles, plastic extrusions", contact:"ensingerplastics.com", notes:"⚪ Engineering Plastics" },
  { id:"h1", name:"Coastal Group", specialty:"Window and door hardware, ironmongery, hinges, handles, locking systems, espagnolettes", contact:"coastal-group.com", notes:"🟧 Hardware / Ironmongery" },
  { id:"h2", name:"Window Ware", specialty:"Window hardware, ironmongery, gaskets, seals, fixings, handles, shootbolts", contact:"windowware.co.uk", notes:"🟧 Hardware / Ironmongery" },
  { id:"h3", name:"Commercial Hardware", specialty:"Commercial ironmongery, door hardware, locking systems, commercial hinges", contact:"commercialhardware.co.uk", notes:"🟧 Hardware / Ironmongery" },
  { id:"h4", name:"GEZE", specialty:"Automatic door systems, door controls, window actuators, wave-to-open sensors, building automation hardware", contact:"geze.com", notes:"🟧 Hardware / Ironmongery" },
  { id:"h5", name:"dormakaba", specialty:"Access control, door hardware, automatic doors, security door systems", contact:"dormakaba.com", notes:"🟧 Hardware / Ironmongery" },
  { id:"d1", name:"Spitfire Doors", specialty:"Aluminium entrance doors, designer doors, residential and commercial entrance doors", contact:"spitfiredoors.co.uk", notes:"🟪 Specialist Doors" },
  { id:"d2", name:"Next Doors", specialty:"Aluminium doors, specialist doors, commercial entrance systems", contact:"next-doors.com", notes:"🟪 Specialist Doors" },
  { id:"as1", name:"Elite Access Solutions", specialty:"Access control systems, automatic gates, barriers, intercom systems, access panels", contact:"eliteaccesssolutions.co.uk", notes:"🟫 Access Systems" },
  { id:"r1", name:"EJOT", specialty:"Facade fixings, cladding fixings, screws, fasteners, thermal facade connectors, anchors", contact:"ejot.co.uk", notes:"⚙️ Fixings / Metals" },
  { id:"r2", name:"Fixfast", specialty:"Roofing and cladding fixings, facade fasteners, structural fixings, seam roofing fixings", contact:"fixfast.com", notes:"⚙️ Fixings / Metals" },
  { id:"r3", name:"Metal Solutions", specialty:"Metal sheet materials, steel, aluminium, metal roofing, metal cladding", contact:"metalsolutions.uk.com", notes:"⚙️ Fixings / Metals" },
  { id:"r4", name:"Stainless Steel Services", specialty:"Stainless steel materials, cut to size, sheets, tubes, fittings, balustrades", contact:"stainlesssteelservices.co.uk", notes:"⚙️ Fixings / Metals" }
];

exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  const store = getStore({ name: 'fcl-suppliers', consistency: 'strong' });

  if (event.httpMethod === 'GET') {
    try {
      const data = await store.get('list', { type: 'json' });
      if (!data || !Array.isArray(data) || data.length === 0) {
        await store.setJSON('list', INITIAL_SUPPLIERS);
        return { statusCode: 200, headers, body: JSON.stringify(INITIAL_SUPPLIERS) };
      }
      return { statusCode: 200, headers, body: JSON.stringify(data) };
    } catch {
      return { statusCode: 200, headers, body: JSON.stringify(INITIAL_SUPPLIERS) };
    }
  }

  if (event.httpMethod === 'POST') {
    try {
      const suppliers = JSON.parse(event.body);
      await store.setJSON('list', suppliers);
      return { statusCode: 200, headers, body: JSON.stringify({ ok: true }) };
    } catch (err) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: err.message }) };
    }
  }

  return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
};
