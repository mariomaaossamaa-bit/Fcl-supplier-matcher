exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers, body: '' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };

  try {
    const { enquiry, suppliers } = JSON.parse(event.body);

    const list = suppliers
      .map(s => `• ${s.name} — ${s.specialty} [${s.notes}]`)
      .join('\n');

    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        system: `You are a procurement routing assistant for Façade Creations Limited, a UK specialist in façade engineering and architectural aluminium fenestration.\n\nSupplier database:\n${list}\n\nAnalyse the enquiry and identify the best matching supplier(s). Consider product type, materials, fire-rating requirements, automation/hardware needs, and project scale (major vs standard).\n\nRespond ONLY with valid JSON (no markdown, no extra text):\n{"recommended":[{"name":"Supplier Name","reason":"One clear sentence"}],"notes":"Additional guidance or null"}`,
        messages: [{ role: 'user', content: enquiry }]
      })
    });

    const data = await res.json();
    const raw = data.content?.find(b => b.type === 'text')?.text || '{}';
    const result = JSON.parse(raw.replace(/```json\n?|```/g, '').trim());

    return { statusCode: 200, headers, body: JSON.stringify(result) };
  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message }) };
  }
};
